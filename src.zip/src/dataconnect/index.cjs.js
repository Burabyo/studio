
const connectorConfig = {
  connector: 'default',
  service: 'studio',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
