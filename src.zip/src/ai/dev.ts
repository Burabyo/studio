
'use server';

import { config } from 'dotenv';
config();

// This file is now used only for Genkit development purposes
// and does not contain the employee creation logic anymore.
// All backend logic has been moved to a standard Firebase Callable 
// function in src/ai/functions.ts for stability and security.
