"use client";

import React, { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  getAuth,
  onAuthStateChanged,
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { app, db } from "@/lib/firebase";
import type { User as AppUser } from "@/lib/types";
import { createNewCompany } from "@/lib/company";
import { toast } from "@/hooks/use-toast";

interface SignupParams {
  email: string;
  password: string;
  name: string;
  isAdmin: boolean;
  companyName?: string;
}

interface AuthContextType {
  user: AppUser | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  signup: (params: SignupParams) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const auth = getAuth(app);

  // Listen for auth changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setLoading(true);
      if (fbUser) {
        try {
          const userDocRef = doc(db, "users", fbUser.uid);
          const userDoc = await getDoc(userDocRef);

          if (userDoc.exists()) {
            const userData = userDoc.data();
            const appUser: AppUser = {
              uid: fbUser.uid,
              email: fbUser.email,
              name: userData.name || fbUser.email || "User",
              role: userData.role || "employee",
              employeeId: userData.employeeId || "",
              companyId: userData.companyId || null,
              firebaseUser: fbUser,
            };
            setUser(appUser);

            // Redirect only if on login/signup
            if (window.location.pathname.startsWith("/login") || window.location.pathname.startsWith("/signup")) {
              router.push("/dashboard");
            }
          } else {
            console.warn("User doc missing, waiting for signup to create it.");
            // Don't force signOut here
          }
        } catch (error) {
          console.error("Error fetching user profile:", error);
          toast({
            variant: "destructive",
            title: "Auth Error",
            description: "Could not fetch user profile.",
          });
        }
      } else {
        setUser(null);
        if (!window.location.pathname.startsWith("/login")) {
          router.push("/login");
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  // Login
  const login = async (email: string, pass: string) => {
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      // redirect handled by onAuthStateChanged
    } catch (error: any) {
      console.error("LOGIN FAILED:", error);
      toast({
        variant: "destructive",
        title: "Login Failed",
        description: error.message || "Invalid credentials or network error.",
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Signup (first admin or admin creating another user)
  const signup = async ({ email, password, name, isAdmin, companyName }: SignupParams) => {
    setLoading(true);
    try {
      if (!isAdmin || !companyName) {
        throw new Error("Signup is only for company admins with a company name.");
      }

      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const fbUser = userCredential.user;

      // Create company and user doc
      const { companyId } = await createNewCompany(companyName);

      const userProfile: Omit<AppUser, "firebaseUser"> = {
        uid: fbUser.uid,
        name,
        email,
        role: "admin",
        companyId,
        employeeId: "",
      };

      await setDoc(doc(db, "users", fbUser.uid), userProfile);

      setUser({ ...userProfile, firebaseUser: fbUser });
      // redirect happens in onAuthStateChanged
    } catch (error: any) {
      console.error("SIGNUP FAILED:", error);
      toast({
        variant: "destructive",
        title: "Signup Failed",
        description: error.message,
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Logout
  const logout = () => {
    signOut(auth)
      .then(() => router.push("/login"))
      .catch((err) => console.error("Logout failed:", err));
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within an AuthProvider");
  return context;
};
